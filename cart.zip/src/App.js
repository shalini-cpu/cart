import "./styles.css";
import ProductList from "./ProductList";

export default function App() {
  return (
    <div className="App">
      <ProductList />
    </div>
  );
}
